<?php
$pengguna=$_POST["username"];
$password=$_POST["password"];
include "koneksi.php";
$kueri=mysqli_query($konek,"INSERT INTO tbl_pengguna (nama,katasandi) VALUE ('$pengguna','$password')");
if($kueri){
	// ini nanti di redirect ke halaman utama
	header("location:lihat_pengguna.php");
}else{
		// ini nanti di redirect ke halaman login
	header("location:tambah_pengguna.php");	
}