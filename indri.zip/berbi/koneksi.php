<?php
$konek=mysqli_connect("localhost","root","","latihan1");
if($konek){
    
	}else{
		echo '<script>window.alert("tidak terkoneksi")</script>'; 
	}
?>