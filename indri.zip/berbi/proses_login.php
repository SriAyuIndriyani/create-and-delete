<?php
$pengguna=$_POST["username"];
$password=$_POST["password"];
include "koneksi.php";
$kueri=mysqli_query($konek,'SELECT * FROM tbl_pengguna WHERE nama="'.$pengguna.'" AND katasandi="'.$password.'"');
if(mysqli_num_rows($kueri)>0){
	// ini nanti di redirect ke halaman utama
	header("location:halaman_beranda.php");
}else{
		// ini nanti di redirect ke halaman login
	header("location:index.php");	
}
