<!DOCTYPE html>
<html>
<head>
	<title>Halaman beranda</title>
	<style type="text/css">
		ul {  
			list-style-type: none;  
		}
        a {
            text-decoration: none;
            color :white;
        }
	</style>
</head>
<body style="color:white;  background-color:black;">
	<table  width="100%" border="1">
		<tr>
            <td colspan="2">
                <center>
                    <h1>SELAMAT DATANG DI TEMPAT</h1>
                    <h1>SRI AYU INDRIYANI</h1>
                </center>
            </td>
		</tr>
		<tr>
			<td width="25%" rowspan="2">
                <ul>
                    <li>
                        <a href="#"><h1>Home</h1></a>
                    </li>
                    <li>
                        <a href="lihat_pengguna.php"><h1>Lihat Pengguna</h1></a>
                    </li>
                </ul>
			</td>
			<td>
                <center>
                    <h1>Beranda</h1>
                </center>
			</td>
		</tr>
        <tr>
            <td>
                <h3>Nama : Sri Ayu Indriyani</h3>
                <h3>Nim : 202113031</h3>
                <h3>Prodi : Teknik Informatika</h3>
            </td>
        </tr>
	</table>
</body>
</html>