<!DOCTYPE html>
<html>
<head>
	<title>Halaman beranda</title>
	<style type="text/css">
		ul {  
			list-style-type: none;  
		}
        a {
            text-decoration: none;
            color :white;
        }
	</style>
</head>
<body style="color:white;  background-color:black;">
	<table  width="100%" border="1">
		<tr>
            <td colspan="2">
                <center>
                    <h1>SELAMAT DATANG DI TEMPAT</h1>
                    <h1>SRI AYU INDRIYANI</h1>
                </center>
            </td>
		</tr>
		<tr>
			<td width="25%" rowspan="2">
                <ul>
                    <li>
                        <a href="halaman_beranda.php"><h1>Home</h1></a>
                    </li>
                    <li>
                        <a href="lihat_pengguna.php"><h1>Lihat Pengguna</h1></a>
                    </li>
                </ul>
			</td>
			<td>
                <center>
                    <h1>Lihat Pengguna</h1>
                </center>
			</td>
		</tr>
        <tr>
            <td>
            <center>
            <?php 
                    include "koneksi.php";
                    $kueri=mysqli_query($konek,'SELECT * FROM tbl_pengguna');
                    ?>
                    <table border="1">
                        
                        <tr>

                            <td>
                                <b>
                                Nama Pengguna
                            </b>
                            </td>
                            <td>
                                <b>
                                Sandi Pengguna
                            </b>
                            </td>
                            <td>
                                <b>
                                Aksi
                                </b>
                            </td>
                        </tr>

                    <?php
                    while($row = mysqli_fetch_array($kueri)){
                        echo"<tr><td>";
                        echo $row['nama'];
                        echo"</td><td>";
                        echo $row['katasandi'];
                        echo"</td>
                        <td>";
                        echo"
                            <a href='hapus.php?apanih=".$row['nama']."'>Hapus</a>
                        ";
                    }
                ?>
                </table>
                <br>
                <button style="background-color: red;"><a href="tambah_pengguna.php">Tambah Pengguna</a></button>
                </center>
            </td>
        </tr>
	</table>
</body>
</html>