<?php 
$id=$_GET['apanih'];
include "koneksi.php";
mysqli_query($konek,'DELETE FROM tbl_pengguna WHERE nama="'.$id.'"');
header("location:lihat_pengguna.php");
?>